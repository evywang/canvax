canvax
======

小型轻便的canvas 图形框架，支持像操作dom一样的 进行canvas编程， 在canvas开发中的对象模型和事件绑定机制拉到了和 dom svg 等开发的同等水平，那么，你还在犹豫什么。
